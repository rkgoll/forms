<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
      <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Yodlee Sample App</title>
      <link rel="STYLESHEET" type="text/css" href="style/fg_membersite.css" />
</head>
<body>
<div id='fg_membersite_content'>
<h2>Yodlee PFM/Aggregation - Sample App</h2>
<ul>
<div id='fg_membersite'>
<fieldset >
<legend>Login</legend>
<li><a href='cobrandLogin.php'>Cobrand Login</a></li>
<li><a href='userLogin.php'>User Login</a></li>
</fieldset>
</div>

<br/>
<div id='fg_membersite'>
<fieldset>
<legend>PFM</legend>
<li><a href='accountsApp.php'>Account Details</a></li>
<li><a href='transactionsApp.php'>Transaction Details</a></li>
</fieldset>
</div>

</ul>
</div>
</body>
</html>